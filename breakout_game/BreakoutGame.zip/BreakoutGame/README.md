# README #

* Breakout is an Android Game in which user break the bricks using a ball
* User can be in the game as long as ball does not miss the paddle
* Game keeps track of top 10 scores

* Version : 1.0

* An open source code, anyone can use the code and modify it accordingly



###  Use Instruction ###
1. Clone the repo using command 'git clone https://github.com/Murdocc007/BreakoutGame'
2. Open the cloned repo in Android Studio using 'existing project' option
3. Compile and run, install the app in an Android device

[![ScreenShot](http://img.youtube.com/vi/X8RzFZnFHUE/0.jpg)](https://www.youtube.com/watch?v=X8RzFZnFHUE)
